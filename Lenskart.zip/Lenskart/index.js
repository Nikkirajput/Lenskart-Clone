let banner2 = document.querySelector(".banner2")
let left_arow = document.querySelector(".left_arow")
let right_arow = document.querySelector('.right_arow')
let left_var = 0
left_arow.onclick = () =>{
    if(left_var == 0){
        banner2.classList.remove("web6")
        banner2.classList.add('web1')
        left_var = 1
       }
       else if(left_var == 1){
        banner2.classList.remove("web1")
        banner2.classList.add('web2')
        left_var = 2
       }
       else if(left_var == 2){
        banner2.classList.remove("web2")
        banner2.classList.add('web3')
        left_var = 3
       }
       else if(left_var == 3){
        banner2.classList.remove("web3")
        banner2.classList.add('web4')
        left_var = 4
       }
       else if(left_var == 4){
        banner2.classList.remove("web4")
        banner2.classList.add('web5')
        left_var = 5
       }
       else if(left_var == 5){
        banner2.classList.remove("web5")
        banner2.classList.add('web6')
        left_var = 0
       }
}

right_arow.onclick = () =>{
    if(left_var == 1){
        banner2.classList.remove("web1")
        banner2.classList.add('web6')
        left_var = 0
       }
       else if(left_var == 2){
        banner2.classList.remove("web2")
        banner2.classList.add('web1')
        left_var = 1
       }
       else if(left_var == 3){
        banner2.classList.remove("web3")
        banner2.classList.add('web2')
        left_var = 2
       }
       else if(left_var == 4){
        banner2.classList.remove("web4")
        banner2.classList.add('web3')
        left_var = 3
       }
       else if(left_var == 5){
        banner2.classList.remove("web5")
        banner2.classList.add('web4')
        left_var = 4
       }
       else if(left_var == 0){
        banner2.classList.remove("web6")
        banner2.classList.add('web5')
        left_var = 5
       }
}
// responsive wala banner part.....................
let banner22 = document.getElementById("#banner22")
let var1 = 0
banner22.onclick = () =>{
    if(var1 == 0){
        banner22.classList.remove("w6")
        banner22.classList.add('w1')
        var1 = 1
       }
       else if(var1 == 1){
        banner22.classList.remove("w1")
        banner22.classList.add('w2')
        var1 = 2
       }
       else if(var1 == 2){
        banner22.classList.remove("w2")
        banner22.classList.add('w3')
        var1 = 3
       }
       else if(var1 == 3){
        banner22.classList.remove("w3")
        banner22.classList.add('w4')
        var1 = 4
       }
       else if(var1 == 4){
        banner22.classList.remove("w4")
        banner22.classList.add('w5')
        var1 = 5
       }
       else if(var1 == 5){
        banner22.classList.remove("w5")
        banner22.classList.add('w6')
        var1 = 0
       }
}

let line3 = document.querySelector(".line_three")
let side_line = document.querySelector(".pointer")
let line = 0
side_line.onclick = () =>{
       if(line == 0){
        line3.classList.add("line3")
        line =1
       }
       else if (line ==1){
        line3.classList.remove("line3")
        line = 0
       }
}